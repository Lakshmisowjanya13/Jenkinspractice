package com.RMP.resource_management.Repository;


import com.RMP.resource_management.Model.Share;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ShareRepository extends JpaRepository<Share, Long> {

}
